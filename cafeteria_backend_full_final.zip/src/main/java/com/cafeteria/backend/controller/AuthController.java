package com.cafeteria.backend.controller;

import com.cafeteria.backend.model.Cliente;
import com.cafeteria.backend.repository.ClienteRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class AuthController {

    private final ClienteRepository repo;

    public AuthController(ClienteRepository repo) {
        this.repo = repo;
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String,String> body) {
        var email = body.get("email");
        var senha = body.get("senha");

        var clienteOpt = repo.findByEmail(email);
        if (clienteOpt.isEmpty()) {
            return ResponseEntity.status(401).body(Map.of("message","Usuário não encontrado"));
        }

        var cliente = clienteOpt.get();
        if (!cliente.getSenhaHash().equals(senha)) {
            return ResponseEntity.status(401).body(Map.of("message","Senha inválida"));
        }

        return ResponseEntity.ok(Map.of(
            "message","Login efetuado",
            "id_cliente",cliente.getId(),
            "nome",cliente.getNome()
        ));
    }
}
